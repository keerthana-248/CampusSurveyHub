package com.JavaProject.SurveyProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurveyProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurveyProjectApplication.class, args);
	}

}
